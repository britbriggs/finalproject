/* 
 * File:   rangeFinder.h
 * Author: Brit Briggs
 *
 * Created on April 24, 2016, 6:32 PM
 */

#ifndef RANGEFINDER_H
#define	RANGEFINDER_H

#ifdef	__cplusplus
extern "C" {
#endif

    void initRangeFinder();
    int rangeFind();
    
    

#ifdef	__cplusplus
}
#endif

#endif	/* RANGEFINDER_H */

