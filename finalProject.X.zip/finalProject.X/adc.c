
#include <xc.h>
#include "adc.h"

#define BLACK 0
#define WHITE 1
#define SHARPLEFT 101
#define SHARPRIGHT 102
#define MOVEFORWARD 103
#define TURNAROUND 104
#define TURNLEFT 105
#define TURNRIGHT 106
#define REVERSE 107


volatile int check = 1;
volatile int rightSensor=100;
volatile int leftSensor=100;
volatile int frontSensor=100;

void initADC(){
    ANSELBbits.ANSB0 = 0;
    ANSELBbits.ANSB1 = 0;
    ANSELBbits.ANSB2 = 0;
    
    AD1CON1bits.ADON=0;
    AD1CON1bits.FORM = 0; // 16 unsigned integer
    AD1CON1bits.SSRC = 7; // Auto-convert mode
    AD1CON1bits.ASAM = 1; // Auto-sampling
    AD1CON2bits.VCFG = 0; // Use board reference voltages
    AD1CON2bits.CSCNA = 0; // Disable scanning
    AD1CON2bits.SMPI = 15; // 15 burritos
    AD1CON2bits.ALTS = 0; // Only Mux A
    AD1CON3bits.ADRC = 0; // Use PBCLK
    AD1CON3bits.SAMC = 2; // 2 Tad per sample
    AD1CON3bits.ADCS = 0xFF; // 512 times the PBCLK
    AD1CHSbits.CH0NA = 0; // Use Vref- as negative reference
    AD1CHSbits.CH0SA = 0; // Scan AN0 at least
//    IEC0bits.AD1IE = 1;
  //  IPC5bits.AD1IP = 7;
    IFS0bits.AD1IF = 0;
    AD1CON1bits.ADON = 1; // turn on the ADC

}

   

int getADCVal(int pin){
    
    AD1CON1bits.ADON=0;
    
    if(pin==0){
         AD1CHSbits.CH0SA = 0;
    }
    else if(pin==1){
         AD1CHSbits.CH0SA = 1;
    }
    else if(pin==2){
         AD1CHSbits.CH0SA = 2;
    }
    IFS0bits.AD1IF=0;
    AD1CON1bits.ADON=1;
   
    while(check){
        
        if(IFS0bits.AD1IF==1){
              IFS0bits.AD1IF=0;
              check=1;
              return ADC1BUF0;
                
        }
              
     }
}