/* 
 * File:   adc.h
 * Author: Brit Briggs
 *
 * Created on March 19, 2016, 10:55 AM
 */

#ifndef ADC_H
#define	ADC_H

#ifdef	__cplusplus
extern "C" {
#endif

    void initADC();
    int checkSensors();
    int getADCVal(int pin);

#ifdef	__cplusplus
}
#endif

#endif	/* ADC_H */

