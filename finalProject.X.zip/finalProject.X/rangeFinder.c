#include "rangeFinder.h"
#include "timer.h"
#include <xc.h>
// Using RD13 // Pin 9 on J11 as output (Trigger)
// Using RD7  // Pin 11 on J11 as input (Echo)


#define OUTPUT 0
#define INPUT 1

volatile int rangeTemp=0;
volatile int msTime=0;
volatile int rangeChecking = 1;

void initRangeFinder(){
    TRISDbits.TRISD6=INPUT;
    TRISDbits.TRISD12=OUTPUT;
    
    LATDbits.LATD12=0;
    
}


int rangeFind(){
    initTimer3();
    LATDbits.LATD12=1;
    delayUs(10);
    LATDbits.LATD12=0;
    
    while(!PORTDbits.RD6);
    T3CONbits.ON=1;
    while(PORTDbits.RD6);
    T3CONbits.ON=0;
    
    rangeTemp=TMR3/2;
    
    
    
    return rangeTemp;
}