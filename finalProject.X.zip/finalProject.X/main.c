


#include <xc.h>
#include <sys/attribs.h>
#include "adc.h"
#include "config.h"
#include "interrupt.h"
#include "lcd.h"
#include "pwm.h"
#include "switch.h"
#include "rangeFinder.h"

// AN2 = Front Sensor
// AN1 = Left Sensor
// AN0 = Right Sensor

#define BLACK 0
#define WHITE 1
#define SHARPLEFT 101
#define SHARPRIGHT 102
#define MOVEFORWARD 103
#define TURNAROUND 104
#define TURNLEFT 105
#define TURNRIGHT 106
#define REVERSE 107

#define rightMax 600
#define leftMax 600
#define frontMax 600


typedef enum stateTypeEnum{
   rangeCheck,checkSensor, moveForward, turnLeft, turnRight, turnAround, turnSharpLeft, turnSharpRight, reverse
} stateType;

 //volatile stateType state = moveForward;
// volatile stateType state=turnAround;
// volatile stateType state = checkSensor;
 volatile stateType state=rangeCheck;
volatile int previousTurn=2;
volatile int horizontalLine=0;
volatile int delayLeft=0;
volatile int stateFlag=0;
volatile int count=0;
volatile int delayLeftOn=0;


int main(void){
    char analogVoltage[]="00000";
    int i=0;
    
    int sumADC1 = 0;
    int ADCRight=0;
    int ADCLeft=0;
    int ADCFront=0;
    int range=0;
    
    int SensorFlag=0;
    SYSTEMConfigPerformance(10000000);
    initLCD();                  // Initialize LCD
    initSwitch1();
    initHbridge();
    initPWM1();
    initPWM2();
    initADC();
    initRangeFinder();
    
    initTimer2();
    initTimer3();
    initSwitch1();

    enableInterrupts();
    clearLCD();
    
    while(1){
        
        switch(state){
            
            case rangeCheck:
                range=rangeFind();
                sprintf(analogVoltage, "%d", range);
                printStringLCD(analogVoltage);
                for(i=0;i<10;i++){
                    delayUs(1000);
                }
                clearLCD();
                
                
                break;
             
            case checkSensor:
                OC1RS=0;
                OC2RS=0;
                ADCRight=getADCVal(0);
                ADCLeft=getADCVal(1);
                ADCFront=getADCVal(2);
                sprintf(analogVoltage, "%d %d %d", ADCRight, ADCLeft, ADCFront);
                printStringLCD(analogVoltage);
                for(i=0;i<1000;i++){
                    delayUs(500);
                }
                    
                break;
            
            case moveForward:
                
                    OC1RS=700;
                    OC2RS=700;
                  
                if(getADCVal(0)<rightMax && getADCVal(1)<leftMax && getADCVal(2)<frontMax){
                    state=turnAround;     
                }
                
                else{
                    
                    if(getADCVal(1)<leftMax && getADCVal(0)<rightMax &&getADCVal(2)>frontMax){
                        OC1RS=850;
                        OC2RS=0;
                        while(getADCVal(2)>frontMax);
                        count++;
                        
                    }
                    else if(getADCVal(1)<leftMax){
                        state=turnLeft;
                    }
                    else if(getADCVal(0)<rightMax && getADCVal(1)>leftMax){
                        state=turnRight;
                    }
                }
 
                    if(count==2){
                        delayLeftOn=0;
                        count=0;
                    }
                       
               
                break;
                
            case turnLeft:
                        OC1RS=750;
                        OC2RS=0;
                        printStringLCD("Left");
                        if(getADCVal(2)<frontMax && delayLeftOn==1){
                            clearLCD();
                            printStringLCD("Delay Left");
                            for(i=0;i<60;i++){
                                delayUs(1000);
                                if(getADCVal(0)<rightMax && getADCVal(1)<leftMax && getADCVal(2)<frontMax){
                                    state=turnAround;
                                    break;
                                }
                               
                                }
                            for(i=0;i<20;i++){
                                if(getADCVal(2)<frontMax){
                                    state=moveForward;
                                    break;
                                }
                            }
                            
                            
                            count++;
                        }
                        else{
                        while(getADCVal(1)<leftMax){
                            if(getADCVal(0)<rightMax && getADCVal(1)<leftMax && getADCVal(2)<frontMax){
                                state=turnAround;
                                break;
                            }
                            
                        }
                        
                state=moveForward;
                break;    
                        }
            case turnRight:
                    
                    
                    printStringLCD("Right");       
                    if(getADCVal(2)<frontMax){
                        state=moveForward;
                        
                    }
                    else{
                        OC1RS=0;
                    OC2RS=750;
                    while(getADCVal(0)<rightMax && getADCVal(1)>leftMax ){
                        if(getADCVal(0)<rightMax && getADCVal(1)<leftMax && getADCVal(2)<frontMax){
                            state=turnAround;
                            break;
                        }
                    }
                    
                    state=moveForward;
                    }
                break;     
            case turnAround:
                OC2RS=800;         
                OC1RS=800;
                delayLeftOn=1;
                 state=moveForward;
                 printStringLCD("Turn Around");
                for(i=0;i<1000;i++){
                    delayUs(250);
                }
                rightWheelForward = 0b1011; // map OC2 to RD5 r b
                rightWheelBackward = 0b0000; // map OC2 to RD8 r f
                for(i=0;i<600;i++){
                    delayUs(1375);
                }
                while(getADCVal(2)>frontMax);
                rightWheelForward = 0b0000; // map OC2 to RD5 r b
                rightWheelBackward = 0b1011; // map OC2 to RD8 r f
                OC1RS=0;
                OC2RS=0;
                break;
                
//            case sharpRightTurn:
                
                
        }
        clearLCD();
    }
    
    
    return 0;
}


//void __ISR(_CHANGE_NOTICE_VECTOR, IPL7SRS) _CNInterrupt( void ){
//   PORTD;
//   IFS1bits.CNDIF = 0;
//   if(state!=checkSensor&&PORTDbits.RD6==0){
//    state=checkSensor;
//   }
//   else if(PORTDbits.RD6==0){
//       state=moveForward;
//   }
//    
    
   // else{
      
  //  }

//}