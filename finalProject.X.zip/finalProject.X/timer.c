/*
 * File:   timer.c
 * Authors:
 *
 * Created on December 30, 2014, 8:07 PM
 */

#include <xc.h>
#include "timer.h"
#include <stdio.h>

#define preScalar256 3

#define Enable 1
#define defaultPriority 7
#define Down 0
#define Disable 0

void initTimer2(){

    
    TMR2 = 0;
    PR2 = 1023;
    T2CONbits.TCKPS = 0;
    T2CONbits.TCS = 0;
    T2CONbits.ON = 1;

}
void initTimer3(){
    TMR3 = 0;// clear TMR3
    PR3 = 3906;// Initialize PR3
    T3CONbits.TCKPS = 7; // Initialize pre-scalar
    T3CONbits.TCS = 0; // Setting the oscillator
    IEC0bits.T3IE = 0;// Enable the interrupt
    IFS0bits.T3IF = 0;// Put the flag down
    T3CONbits.TON = 0;// Turn the timer on
}

void delayUs(unsigned int delay){

    T1CONbits.TCKPS = 0; //prescalar of 1
    T1CONbits.TCS = 0;
    IFS0bits.T1IF = 0;
    TMR1 = 0;
    PR1 = delay*9;
    T1CONbits.ON = 1;
    while(IFS0bits.T1IF == 0);
    T1CONbits.ON = 0;


 }

char* getTimeString(const long int counter, char* time){
    int milliseconds;
    int seconds;
    int minutes;
    
    
    milliseconds=counter%100;           //%100 gives ms
    
    seconds=(counter/100)%60;           //%600 gives seconds
    minutes=(counter/100)/60;           // /600 gives minutes

    sprintf(time, "%02d:%02d:%02d", minutes, seconds, milliseconds);    //Format String
  
    return time;
    
}