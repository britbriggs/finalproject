/* 
 * File:   switch.h
 * Author: Brit Briggs
 *
 * Created on March 23, 2016, 9:55 PM
 */

#ifndef SWITCH_H
#define	SWITCH_H

#define TRIS_SW1 TRISDbits.TRISD6 // pin 6
#define CNIE_SW1 CNENDbits.CNIED6 //
#define CNPU_SW1 CNPUDbits.CNPUD6
#define SW1 PORTDbits.RD6


    void initSwitch1();



#endif	/* SWITCH_H */

